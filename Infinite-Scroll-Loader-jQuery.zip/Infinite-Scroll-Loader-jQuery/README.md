# jquery-infiniteScroll #

----------
[https://www.oscarlijo.com/infiniteScroll/](https://www.oscarlijo.com/infiniteScroll/ "jquery-infiniteScroll")
<br><br>
**jquery-infiniteScroll** is a jQuery plugin compatible with Zepto.js